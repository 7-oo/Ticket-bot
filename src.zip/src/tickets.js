// @og7oo - انزوكورد
const {
  ChannelType,
  PermissionFlagsBits,
  OverwriteType,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags
} = require('discord.js')
const config = require('../config')
const store = require('./store')
const { t } = require('./locale')
const { isAdmin, isStaff } = require('./perms')
const { panelPayload } = require('./panel')
const { buildTranscript } = require('./transcript')
const { pad } = require('./util')

const P = PermissionFlagsBits
const quiet = MessageFlags.Ephemeral
const talk = [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles, P.EmbedLinks]
const lastOpen = new Map()
const deleting = new Set()

function button(id, label, style) {
  return new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style)
}

function controls(ticket) {
  const claim = ticket.claimedBy
    ? button('ticket:unclaim', t('btnUnclaim'), ButtonStyle.Secondary)
    : button('ticket:claim', t('btnClaim'), ButtonStyle.Success)
  return new ActionRowBuilder().addComponents(claim, button('ticket:close', t('btnClose'), ButtonStyle.Danger))
}

function closedControls() {
  return new ActionRowBuilder().addComponents(
    button('ticket:reopen', t('btnReopen'), ButtonStyle.Secondary),
    button('ticket:delete', t('btnDelete'), ButtonStyle.Danger)
  )
}

function note(text) {
  return new EmbedBuilder().setColor(config.color).setDescription(text)
}

function mention(id) {
  return `<@${id}>`
}

function ownerCanWrite(channel, ownerId, canWrite) {
  return channel.permissionOverwrites
    .edit(ownerId, { SendMessages: canWrite }, { type: OverwriteType.Member })
    .catch(() => {})
}

async function find(interaction) {
  const ticket = store.ticket(interaction.channelId)
  if (!ticket) await interaction.reply({ content: t('notTicket'), flags: quiet })
  return ticket
}

function resetPanel(interaction) {
  const panel = store.panel()
  if (panel && panel.messageId === interaction.message.id) {
    interaction.message.edit(panelPayload(panel)).catch(() => {})
  }
}

async function open(interaction) {
  await interaction.deferReply({ flags: quiet })
  resetPanel(interaction)

  const user = interaction.user
  const guild = interaction.guild
  const section = store.section(interaction.values[0])
  if (!section) return interaction.editReply(t('sectionGone'))

  const block = store.blocked(user.id)
  if (block) {
    return interaction.editReply(block.reason ? `${t('blocked')}\n${block.reason}` : t('blocked'))
  }

  const now = Date.now()
  const wait = (lastOpen.get(user.id) || 0) + config.cooldown * 1000 - now
  if (wait > 0) return interaction.editReply(t('cooldown', { seconds: Math.ceil(wait / 1000) }))

  const limit = store.settings().maxTickets || config.maxTickets
  const mine = store.ticketsOf(user.id)
  if (mine.length >= limit) {
    const where = mine.map(x => `<#${x.channelId}>`).join(' ')
    return interaction.editReply(`${t('limitReached', { count: mine.length })}\n${where}`)
  }
  lastOpen.set(user.id, now)

  const number = store.nextNumber()
  const categoryId = store.settings().categoryId
  const parent = categoryId && guild.channels.cache.has(categoryId) ? categoryId : null
  const roleExists = guild.roles.cache.has(section.roleId)

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [P.ViewChannel] },
    { id: user.id, allow: talk },
    { id: guild.members.me.id, allow: talk }
  ]
  if (roleExists) overwrites.push({ id: section.roleId, allow: talk })

  let channel
  try {
    channel = await guild.channels.create({
      name: `ticket-${pad(number)}`,
      type: ChannelType.GuildText,
      parent,
      topic: `${user.username} (${user.id})`,
      permissionOverwrites: overwrites
    })

    const ticket = store.addTicket({
      channelId: channel.id,
      number,
      ownerId: user.id,
      sectionId: section.id,
      sectionName: section.name,
      claimedBy: null,
      closed: false,
      createdAt: Date.now()
    })

    const embed = new EmbedBuilder()
      .setColor(config.color)
      .setTitle(t('welcomeTitle', { number: pad(number) }))
      .setDescription(t('welcomeText', { user: mention(user.id), section: section.name }))
      .setTimestamp()

    const ping = roleExists ? `${mention(user.id)} <@&${section.roleId}>` : mention(user.id)
    await channel.send({ content: ping, embeds: [embed], components: [controls(ticket)] })
  } catch (err) {
    console.error('Could not create ticket:', err.message)
    if (channel) {
      store.deleteTicket(channel.id)
      channel.delete().catch(() => {})
    }
    lastOpen.delete(user.id)
    return interaction.editReply(t('createFailed'))
  }

  return interaction.editReply(t('ticketCreated', { channel: `<#${channel.id}>` }))
}

async function claim(interaction) {
  const ticket = await find(interaction)
  if (!ticket) return
  if (!isStaff(interaction.member, ticket)) {
    return interaction.reply({ content: t('staffOnly'), flags: quiet })
  }
  if (ticket.claimedBy) {
    return interaction.reply({ content: t('alreadyClaimed', { user: mention(ticket.claimedBy) }), flags: quiet })
  }

  const updated = store.updateTicket(ticket.channelId, { claimedBy: interaction.user.id })
  await interaction.update({ components: [controls(updated)] })
  await interaction.channel.send({ embeds: [note(t('claimed', { user: mention(interaction.user.id) }))] })
}

async function unclaim(interaction) {
  const ticket = await find(interaction)
  if (!ticket) return
  const allowed = ticket.claimedBy === interaction.user.id || isAdmin(interaction.member)
  if (!allowed) {
    return interaction.reply({ content: t('notClaimer', { user: mention(ticket.claimedBy) }), flags: quiet })
  }

  const updated = store.updateTicket(ticket.channelId, { claimedBy: null })
  await interaction.update({ components: [controls(updated)] })
  await interaction.channel.send({ embeds: [note(t('unclaimed', { user: mention(interaction.user.id) }))] })
}

async function close(interaction) {
  const ticket = await find(interaction)
  if (!ticket) return
  const owner = interaction.user.id === ticket.ownerId
  if (!owner && !isStaff(interaction.member, ticket)) {
    return interaction.reply({ content: t('cantClose'), flags: quiet })
  }
  if (ticket.closed) return interaction.reply({ content: t('alreadyClosed'), flags: quiet })

  await interaction.deferUpdate()
  store.updateTicket(ticket.channelId, { closed: true })
  await ownerCanWrite(interaction.channel, ticket.ownerId, false)
  await interaction.editReply({ components: [] })
  await interaction.channel.send({
    embeds: [note(t('closedBy', { user: mention(interaction.user.id) }))],
    components: [closedControls()]
  })
}

async function reopen(interaction) {
  const ticket = await find(interaction)
  if (!ticket) return
  if (!isStaff(interaction.member, ticket)) {
    return interaction.reply({ content: t('staffOnly'), flags: quiet })
  }
  if (!ticket.closed) return interaction.reply({ content: t('notClosed'), flags: quiet })

  await interaction.deferUpdate()
  const updated = store.updateTicket(ticket.channelId, { closed: false })
  await ownerCanWrite(interaction.channel, ticket.ownerId, true)
  await interaction.editReply({ components: [] })
  await interaction.channel.send({
    embeds: [note(t('reopenedBy', { user: mention(interaction.user.id) }))],
    components: [controls(updated)]
  })
}

function logEmbed(ticket, deleterId) {
  return new EmbedBuilder()
    .setColor(config.color)
    .setTitle(t('logTitle', { number: pad(ticket.number) }))
    .addFields(
      { name: t('logOwner'), value: mention(ticket.ownerId), inline: true },
      { name: t('logSection'), value: ticket.sectionName, inline: true },
      { name: t('logClaimed'), value: ticket.claimedBy ? mention(ticket.claimedBy) : t('none'), inline: true },
      { name: t('logDeletedBy'), value: mention(deleterId), inline: true },
      { name: t('logOpened'), value: `<t:${Math.floor(ticket.createdAt / 1000)}:f>`, inline: true }
    )
    .setTimestamp()
}

async function remove(interaction) {
  const ticket = await find(interaction)
  if (!ticket) return
  if (!isStaff(interaction.member, ticket)) {
    return interaction.reply({ content: t('staffOnly'), flags: quiet })
  }
  if (deleting.has(ticket.channelId)) return interaction.deferUpdate()
  deleting.add(ticket.channelId)

  const channel = interaction.channel
  const guild = interaction.guild

  try {
    await interaction.update({ components: [] })
    await channel.send({ embeds: [note(t('deleting'))] })

    const file = await buildTranscript(channel, ticket).catch(err => {
      console.error('Transcript failed:', err.message)
      return null
    })
    const files = file ? [file] : []

    const logId = store.settings().logChannelId
    const logs = logId ? guild.channels.cache.get(logId) : null
    if (logs) {
      await logs.send({ embeds: [logEmbed(ticket, interaction.user.id)], files }).catch(err => {
        console.error('Could not send to the log channel:', err.message)
      })
    }

    if (file) {
      const owner = await interaction.client.users.fetch(ticket.ownerId).catch(() => null)
      if (owner) {
        await owner
          .send({ content: t('dmTranscript', { number: pad(ticket.number), server: guild.name }), files })
          .catch(() => {})
      }
    }

    store.deleteTicket(ticket.channelId)
    setTimeout(() => channel.delete().catch(() => {}), 3000)
  } finally {
    setTimeout(() => deleting.delete(ticket.channelId), 10000)
  }
}

module.exports = { open, claim, unclaim, close, reopen, remove }
