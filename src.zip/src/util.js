// @og7oo - انزوكورد
function pad(number) {
  return String(number).padStart(4, '0')
}

function parseEmoji(text) {
  const custom = text.match(/^<(a?):(\w{2,32}):(\d{17,20})>$/)
  if (custom) return { id: custom[3], name: custom[2], animated: custom[1] === 'a' }

  const unicode = /^\p{Extended_Pictographic}\uFE0F?(\u200D\p{Extended_Pictographic}\uFE0F?)*$/u
  if (unicode.test(text)) return { name: text }

  return null
}

module.exports = { pad, parseEmoji }
