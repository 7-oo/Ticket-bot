// @og7oo - انزوكورد
const fs = require('fs')
const path = require('path')

const dir = path.join(__dirname, '..', 'data')
const file = path.join(dir, 'data.json')

const blank = () => ({
  counter: 0,
  sectionCounter: 0,
  settings: { categoryId: null, logChannelId: null, maxTickets: null },
  panel: null,
  sections: [],
  tickets: {},
  blacklist: {}
})

function load() {
  fs.mkdirSync(dir, { recursive: true })
  if (!fs.existsSync(file)) return blank()
  try {
    const saved = JSON.parse(fs.readFileSync(file, 'utf8'))
    const fresh = blank()
    return { ...fresh, ...saved, settings: { ...fresh.settings, ...saved.settings } }
  } catch (err) {
    const backup = `${file}.broken-${Date.now()}`
    fs.renameSync(file, backup)
    console.error(`The data file could not be read. It was moved to ${backup} and a new one will be created.`)
    return blank()
  }
}

let data = load()
let timer = null

function flush() {
  clearTimeout(timer)
  timer = null
  const tmp = `${file}.tmp`
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2))
  fs.renameSync(tmp, file)
}

function save() {
  clearTimeout(timer)
  timer = setTimeout(flush, 150)
}

process.on('exit', () => {
  if (timer) {
    try {
      flush()
    } catch (err) {
      console.error(err)
    }
  }
})

module.exports = {
  flush,

  settings: () => data.settings,
  setSettings(patch) {
    Object.assign(data.settings, patch)
    save()
  },

  panel: () => data.panel,
  setPanel(panel) {
    data.panel = panel
    save()
  },

  sections: () => data.sections,
  section: id => data.sections.find(s => s.id === id),
  addSection({ name, roleId, emoji, about }) {
    const taken = data.sections.some(s => s.name.toLowerCase() === name.toLowerCase())
    if (taken) return null
    data.sectionCounter += 1
    const section = { id: `s${data.sectionCounter}`, name, roleId, emoji: emoji || null, about: about || null }
    data.sections.push(section)
    save()
    return section
  },
  removeSection(name) {
    const index = data.sections.findIndex(s => s.name.toLowerCase() === name.toLowerCase())
    if (index === -1) return false
    data.sections.splice(index, 1)
    save()
    return true
  },

  nextNumber() {
    data.counter += 1
    save()
    return data.counter
  },
  ticket: channelId => data.tickets[channelId],
  allTickets: () => Object.values(data.tickets),
  ticketsOf: userId => Object.values(data.tickets).filter(t => t.ownerId === userId),
  addTicket(ticket) {
    data.tickets[ticket.channelId] = ticket
    save()
    return ticket
  },
  updateTicket(channelId, patch) {
    const ticket = data.tickets[channelId]
    if (!ticket) return null
    Object.assign(ticket, patch)
    save()
    return ticket
  },
  deleteTicket(channelId) {
    delete data.tickets[channelId]
    save()
  },

  blocked: userId => data.blacklist[userId],
  allBlocked: () => Object.entries(data.blacklist),
  block(userId, reason) {
    data.blacklist[userId] = { reason: reason || null, at: Date.now() }
    save()
  },
  unblock(userId) {
    if (!data.blacklist[userId]) return false
    delete data.blacklist[userId]
    save()
    return true
  }
}
