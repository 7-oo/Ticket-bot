// @og7oo - انزوكورد
const { MessageFlags } = require('discord.js')
const config = require('../config')
const commands = require('./commands')
const tickets = require('./tickets')
const { t } = require('./locale')

const buttons = {
  'ticket:claim': tickets.claim,
  'ticket:unclaim': tickets.unclaim,
  'ticket:close': tickets.close,
  'ticket:reopen': tickets.reopen,
  'ticket:delete': tickets.remove
}

async function handle(interaction) {
  if (interaction.guildId !== config.guildId) return

  if (interaction.isAutocomplete()) {
    const command = commands.byName.get(interaction.commandName)
    if (command && command.autocomplete) await command.autocomplete(interaction)
    return
  }

  if (interaction.isChatInputCommand()) {
    const command = commands.byName.get(interaction.commandName)
    if (command) await command.run(interaction)
    return
  }

  if (interaction.isStringSelectMenu() && interaction.customId === 'ticket:open') {
    return tickets.open(interaction)
  }

  if (interaction.isButton() && buttons[interaction.customId]) {
    return buttons[interaction.customId](interaction)
  }
}

module.exports = async function onInteraction(interaction) {
  try {
    await handle(interaction)
  } catch (err) {
    console.error(err)
    if (!interaction.isRepliable()) return
    const payload = { content: t('error'), flags: MessageFlags.Ephemeral }
    if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {})
    else await interaction.reply(payload).catch(() => {})
  }
}
