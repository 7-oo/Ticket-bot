// @og7oo - انزوكورد
const { PermissionFlagsBits } = require('discord.js')
const store = require('./store')

function isAdmin(member) {
  return member.permissions.has(PermissionFlagsBits.ManageGuild)
}

function isStaff(member, ticket) {
  if (isAdmin(member)) return true
  const section = store.section(ticket.sectionId)
  return Boolean(section && member.roles.cache.has(section.roleId))
}

module.exports = { isAdmin, isStaff }
