// @og7oo - انزوكورد
const config = require('../config')
const en = require('./locales/en')
const ar = require('./locales/ar')

const pack = { en, ar }[config.language] || en

function t(key, vars = {}) {
  const text = pack[key] ?? en[key] ?? key
  return text.replace(/\{(\w+)\}/g, (_, name) => vars[name] ?? '')
}

module.exports = { t }
