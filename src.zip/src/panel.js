// @og7oo - انزوكورد
const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js')
const config = require('../config')
const store = require('./store')
const { t } = require('./locale')

function panelPayload({ title, text }) {
  const sections = store.sections()

  const embed = new EmbedBuilder()
    .setColor(config.color)
    .setTitle(title)
    .setDescription(text)

  if (!sections.length) return { embeds: [embed], components: [] }

  const options = sections.map(section => {
    const option = { label: section.name, value: section.id }
    if (section.about) option.description = section.about
    if (section.emoji) option.emoji = section.emoji
    return option
  })

  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket:open')
    .setPlaceholder(t('selectPlaceholder'))
    .addOptions(options)

  return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] }
}

async function refreshPanel(client) {
  const panel = store.panel()
  if (!panel) return
  try {
    const channel = await client.channels.fetch(panel.channelId)
    const message = await channel.messages.fetch(panel.messageId)
    await message.edit(panelPayload(panel))
  } catch (err) {
    console.error('Could not refresh the panel message:', err.message)
  }
}

module.exports = { panelPayload, refreshPanel }
