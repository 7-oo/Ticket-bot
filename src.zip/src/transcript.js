// @og7oo - انزوكورد
const { AttachmentBuilder, GatewayIntentBits } = require('discord.js')
const { t } = require('./locale')
const { pad } = require('./util')

const maxMessages = 1500

function esc(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

async function collect(channel) {
  const all = []
  let before
  while (all.length < maxMessages) {
    const batch = await channel.messages.fetch({ limit: 100, before })
    if (!batch.size) break
    all.push(...batch.values())
    before = batch.last().id
  }
  return all.reverse()
}

function row(message) {
  const name = message.member ? message.member.displayName : message.author.username
  const time = message.createdAt.toISOString().replace('T', ' ').slice(0, 19)
  const text = esc(message.content).replace(/\n/g, '<br>')

  const embeds = message.embeds
    .map(e => [e.title, e.description].filter(Boolean).join(' - '))
    .filter(Boolean)
    .map(e => `<div class="embed">${esc(e).replace(/\n/g, '<br>')}</div>`)
    .join('')

  const files = [...message.attachments.values()]
    .map(a => `<a href="${esc(a.url)}">${esc(a.name)}</a>`)
    .join(' ')

  return `<div class="msg"><b>${esc(name)}</b> <span>${time} UTC</span><p dir="auto">${text}</p>${embeds}${files ? `<p>${files}</p>` : ''}</div>`
}

async function buildTranscript(channel, ticket) {
  const messages = await collect(channel)
  const hasContent = channel.client.options.intents.has(GatewayIntentBits.MessageContent)
  const warning = hasContent ? '' : `<p class="warn">${esc(t('transcriptNote'))}</p>`

  const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Ticket ${pad(ticket.number)}</title>
<style>
body { font-family: sans-serif; background: #313338; color: #dbdee1; max-width: 800px; margin: 30px auto; padding: 0 15px; }
h1 { font-size: 20px; }
.msg { padding: 8px 0; border-bottom: 1px solid #3f4147; }
.msg span { color: #949ba4; font-size: 12px; margin-left: 6px; }
.msg p { margin: 4px 0 0; }
.embed { border-left: 3px solid #5865f2; padding: 4px 10px; margin-top: 4px; background: #2b2d31; }
.warn { color: #f0b232; }
a { color: #00a8fc; }
</style>
</head>
<body>
<h1>${esc(channel.guild.name)} - Ticket ${pad(ticket.number)} (${esc(ticket.sectionName)})</h1>
${warning}
${messages.map(row).join('\n')}
</body>
</html>`

  return new AttachmentBuilder(Buffer.from(html, 'utf8'), { name: `ticket-${pad(ticket.number)}.html` })
}

module.exports = { buildTranscript }
