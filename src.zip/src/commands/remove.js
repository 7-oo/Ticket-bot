// @og7oo - انزوكورد
const { SlashCommandBuilder, MessageFlags } = require('discord.js')
const store = require('../store')
const { t } = require('../locale')
const { isStaff } = require('../perms')

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remove')
    .setDescription(t('cmdRemove'))
    .addUserOption(o => o.setName('member').setDescription(t('optMember')).setRequired(true)),

  async run(interaction) {
    const ticket = store.ticket(interaction.channelId)
    if (!ticket) return interaction.reply({ content: t('notTicket'), flags: MessageFlags.Ephemeral })
    if (!isStaff(interaction.member, ticket)) {
      return interaction.reply({ content: t('staffOnly'), flags: MessageFlags.Ephemeral })
    }

    const user = interaction.options.getUser('member')
    if (user.id === ticket.ownerId) {
      return interaction.reply({ content: t('cantRemoveOwner'), flags: MessageFlags.Ephemeral })
    }

    await interaction.channel.permissionOverwrites.delete(user.id)
    await interaction.reply(t('memberRemoved', { user: `<@${user.id}>` }))
  }
}
