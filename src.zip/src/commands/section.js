// @og7oo - انزوكورد
const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js')
const store = require('../store')
const { t } = require('../locale')
const { refreshPanel } = require('../panel')
const { parseEmoji } = require('../util')

const quiet = MessageFlags.Ephemeral

module.exports = {
  data: new SlashCommandBuilder()
    .setName('section')
    .setDescription(t('cmdSection'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription(t('cmdSectionAdd'))
      .addStringOption(o => o.setName('name').setDescription(t('optSectionName')).setRequired(true).setMaxLength(80))
      .addRoleOption(o => o.setName('role').setDescription(t('optSectionRole')).setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription(t('optSectionEmoji')))
      .addStringOption(o => o.setName('about').setDescription(t('optSectionAbout')).setMaxLength(100)))
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription(t('cmdSectionRemove'))
      .addStringOption(o => o.setName('name').setDescription(t('optSectionName')).setRequired(true).setAutocomplete(true)))
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription(t('cmdSectionList'))),

  async autocomplete(interaction) {
    const typed = interaction.options.getFocused().toLowerCase()
    const matches = store.sections()
      .filter(s => s.name.toLowerCase().includes(typed))
      .slice(0, 25)
    await interaction.respond(matches.map(s => ({ name: s.name, value: s.name })))
  },

  async run(interaction) {
    const sub = interaction.options.getSubcommand()

    if (sub === 'add') {
      const name = interaction.options.getString('name').trim()
      const role = interaction.options.getRole('role')
      const emojiText = interaction.options.getString('emoji')
      const about = interaction.options.getString('about')

      let emoji = null
      if (emojiText) {
        emoji = parseEmoji(emojiText.trim())
        if (!emoji) return interaction.reply({ content: t('badEmoji'), flags: quiet })
      }

      if (store.sections().length >= 25) {
        return interaction.reply({ content: t('sectionLimit'), flags: quiet })
      }

      const added = store.addSection({ name, roleId: role.id, emoji, about })
      if (!added) return interaction.reply({ content: t('sectionExists'), flags: quiet })

      await interaction.reply({ content: t('sectionAdded', { name }), flags: quiet })
      return refreshPanel(interaction.client)
    }

    if (sub === 'remove') {
      const name = interaction.options.getString('name')
      if (!store.removeSection(name)) {
        return interaction.reply({ content: t('sectionMissing'), flags: quiet })
      }
      await interaction.reply({ content: t('sectionRemoved', { name }), flags: quiet })
      return refreshPanel(interaction.client)
    }

    const sections = store.sections()
    if (!sections.length) return interaction.reply({ content: t('sectionsEmpty'), flags: quiet })

    const lines = sections.map(s => {
      const icon = s.emoji ? (s.emoji.id ? `<${s.emoji.animated ? 'a' : ''}:${s.emoji.name}:${s.emoji.id}>` : s.emoji.name) : ''
      return t('sectionLine', { emoji: icon, name: s.name, role: s.roleId }).trim()
    })
    return interaction.reply({ content: lines.join('\n'), flags: quiet })
  }
}
