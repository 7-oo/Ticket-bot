// @og7oo - انزوكورد
const names = ['setup', 'section', 'config', 'add', 'remove', 'blacklist', 'help']
const list = names.map(name => require(`./${name}`))

module.exports = {
  byName: new Map(list.map(command => [command.data.name, command])),
  payload: () => list.map(command => command.data.toJSON())
}
