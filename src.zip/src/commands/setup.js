// @og7oo - انزوكورد
const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js')
const store = require('../store')
const { t } = require('../locale')
const { panelPayload } = require('../panel')

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription(t('cmdSetup'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption(o => o.setName('title').setDescription(t('optPanelTitle')).setMaxLength(100))
    .addStringOption(o => o.setName('text').setDescription(t('optPanelText')).setMaxLength(1500)),

  async run(interaction) {
    if (!store.sections().length) {
      return interaction.reply({ content: t('noSections'), flags: MessageFlags.Ephemeral })
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral })

    const title = interaction.options.getString('title') || t('panelTitle')
    const text = interaction.options.getString('text') || t('panelText')
    const sent = await interaction.channel.send(panelPayload({ title, text }))

    store.setPanel({ channelId: sent.channelId, messageId: sent.id, title, text })
    await interaction.editReply(t('panelSent'))
  }
}
