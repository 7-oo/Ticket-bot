// @og7oo - انزوكورد
const { SlashCommandBuilder, MessageFlags, OverwriteType } = require('discord.js')
const store = require('../store')
const { t } = require('../locale')
const { isStaff } = require('../perms')

module.exports = {
  data: new SlashCommandBuilder()
    .setName('add')
    .setDescription(t('cmdAdd'))
    .addUserOption(o => o.setName('member').setDescription(t('optMember')).setRequired(true)),

  async run(interaction) {
    const ticket = store.ticket(interaction.channelId)
    if (!ticket) return interaction.reply({ content: t('notTicket'), flags: MessageFlags.Ephemeral })
    if (!isStaff(interaction.member, ticket)) {
      return interaction.reply({ content: t('staffOnly'), flags: MessageFlags.Ephemeral })
    }

    const user = interaction.options.getUser('member')
    await interaction.channel.permissionOverwrites.edit(
      user.id,
      {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true,
        AttachFiles: true,
        EmbedLinks: true
      },
      { type: OverwriteType.Member }
    )
    await interaction.reply(t('memberAdded', { user: `<@${user.id}>` }))
  }
}
