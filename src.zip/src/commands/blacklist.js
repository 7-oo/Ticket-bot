// @og7oo - انزوكورد
const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js')
const store = require('../store')
const { t } = require('../locale')

const quiet = MessageFlags.Ephemeral

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription(t('cmdBlacklist'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription(t('cmdBlacklistAdd'))
      .addUserOption(o => o.setName('member').setDescription(t('optMember')).setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription(t('optReason')).setMaxLength(200)))
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription(t('cmdBlacklistRemove'))
      .addUserOption(o => o.setName('member').setDescription(t('optMember')).setRequired(true)))
    .addSubcommand(sub => sub
      .setName('list')
      .setDescription(t('cmdBlacklistList'))),

  async run(interaction) {
    const sub = interaction.options.getSubcommand()

    if (sub === 'add') {
      const user = interaction.options.getUser('member')
      store.block(user.id, interaction.options.getString('reason'))
      return interaction.reply({ content: t('blAdded', { user: `<@${user.id}>` }), flags: quiet })
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('member')
      const done = store.unblock(user.id)
      const key = done ? 'blRemoved' : 'blNotFound'
      return interaction.reply({ content: t(key, { user: `<@${user.id}>` }), flags: quiet })
    }

    const all = store.allBlocked()
    if (!all.length) return interaction.reply({ content: t('blEmpty'), flags: quiet })

    const lines = all.slice(0, 40).map(([id, info]) => t('blLine', { id, reason: info.reason || '' }).trim())
    return interaction.reply({ content: lines.join('\n'), flags: quiet })
  }
}
