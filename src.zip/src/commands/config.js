// @og7oo - انزوكورد
const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, MessageFlags } = require('discord.js')
const store = require('../store')
const defaults = require('../../config')
const { t } = require('../locale')

module.exports = {
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription(t('cmdConfig'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption(o => o
      .setName('category')
      .setDescription(t('optCategory'))
      .addChannelTypes(ChannelType.GuildCategory))
    .addChannelOption(o => o
      .setName('logs')
      .setDescription(t('optLogs'))
      .addChannelTypes(ChannelType.GuildText))
    .addIntegerOption(o => o
      .setName('max_tickets')
      .setDescription(t('optMax'))
      .setMinValue(1)
      .setMaxValue(10)),

  async run(interaction) {
    const category = interaction.options.getChannel('category')
    const logs = interaction.options.getChannel('logs')
    const max = interaction.options.getInteger('max_tickets')

    const patch = {}
    if (category) patch.categoryId = category.id
    if (logs) patch.logChannelId = logs.id
    if (max) patch.maxTickets = max

    if (Object.keys(patch).length) {
      store.setSettings(patch)
      return interaction.reply({ content: t('configSaved'), flags: MessageFlags.Ephemeral })
    }

    const s = store.settings()
    const lines = [
      t('configCategory', { value: s.categoryId ? `<#${s.categoryId}>` : '-' }),
      t('configLogs', { value: s.logChannelId ? `<#${s.logChannelId}>` : '-' }),
      t('configMax', { value: s.maxTickets || defaults.maxTickets })
    ]
    return interaction.reply({ content: lines.join('\n'), flags: MessageFlags.Ephemeral })
  }
}
