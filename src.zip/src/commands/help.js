// @og7oo - انزوكورد
const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js')
const config = require('../../config')
const { t } = require('../locale')

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription(t('cmdHelp')),

  async run(interaction) {
    const embed = new EmbedBuilder()
      .setColor(config.color)
      .setTitle(t('helpTitle'))
      .setDescription(t('helpText'))
    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral })
  }
}
